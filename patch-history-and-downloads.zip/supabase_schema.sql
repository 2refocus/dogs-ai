-- Tables for credits (optional), generations, payments (optional minimal)
create table if not exists public.generations (
  id bigserial primary key,
  user_id uuid references auth.users(id) on delete set null,
  created_at timestamptz not null default now(),
  species text,
  preset_label text,
  prompt text,
  output_url text not null
);

-- Basic RLS: allow user to read only their rows; service role can insert
alter table public.generations enable row level security;

do $$ begin
  create policy "select own generations"
    on public.generations for select
    using (auth.uid() = user_id);
exception when duplicate_object then null; end $$;

do $$ begin
  create policy "insert via service only"
    on public.generations for insert
    with check (auth.role() = 'service_role');
exception when duplicate_object then null; end $$;
