import { NextRequest } from "next/server";

export const runtime = "edge";

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const url = searchParams.get("url");
  if (!url) return new Response("Missing url", { status: 400 });

  try {
    const target = new URL(url);
    if (!/^https?:$/.test(target.protocol)) return new Response("Invalid protocol", { status: 400 });

    const res = await fetch(target.toString(), { headers: { Accept: "*/*" } });
    const contentType = res.headers.get("content-type") || "application/octet-stream";
    return new Response(res.body, {
      status: res.status,
      headers: {
        "content-type": contentType,
        "cache-control": "public, max-age=31536000, immutable"
      }
    });
  } catch (e: any) {
    return new Response(e.message || "Proxy failed", { status: 500 });
  }
}
