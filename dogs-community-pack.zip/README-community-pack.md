# Community Pack (Homepage + /community)

This pack adds:
- `app/components/CommunityGrid.tsx` (client presentational grid)
- `app/components/CommunityFeed.tsx` (server component that fetches 24 latest public rows)
- `app/community/page.tsx` (full community page)

## How to wire on the homepage

In your **app/page.tsx**, import and render **CommunityFeed** underneath your generator:

```tsx
import dynamic from "next/dynamic";
const CommunityFeed = dynamic(() => import("./components/CommunityFeed"), { ssr: true });

export default function Page() {
  return (
    <main className="...">
      {/* your existing generator UI */}

      <div className="mt-8">
        <hr className="my-6 opacity-20" />
        <CommunityFeed />
      </div>
    </main>
  );
}
```

## Requirements

- Table: `public.generations` with columns at least: `id`, `output_url`, `preset_label (nullable)`, `created_at`, `is_public boolean`.
- RLS policy that allows *public* selects of rows where `is_public = true`.
- Insert flow (e.g., in /api/stylize) should set `is_public: true` for items you want to appear.

## Notes

- We use plain `<img>` tags to avoid Next image domain config surprises.
- `revalidate = 60` keeps it fresh without hammering Supabase.
