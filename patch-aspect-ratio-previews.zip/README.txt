
// In your app/page.tsx onSubmit handler before fetch('/api/stylize'):
// const ar = (typeof window !== 'undefined' && localStorage.getItem('aspectRatio')) || '1:1';
// fd.append('aspectRatio', ar);
